package com.sotnikov.server;

import java.util.ArrayList;

public class MessagesJson {
    public ArrayList<String> messages;
    public ArrayList<String> names;

}
