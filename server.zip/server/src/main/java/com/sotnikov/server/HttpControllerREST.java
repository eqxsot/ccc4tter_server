package com.sotnikov.server;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import com.google.gson.*;

import java.io.*;
import java.util.logging.Handler;

@RestController
public class HttpControllerREST extends HttpServlet {
    String jsonMsgs;
    String datapath = "C:\\Users\\Second User\\IdeaProjects\\server\\src\\main\\java\\com\\sotnikov\\server\\data.json";
    @RequestMapping("/")
    public String index(HttpServletRequest request, HttpServletResponse response) {
        new Thread() {
            public void run() {
                try
                {
                    File file = new File(datapath);
                    FileReader fr = new FileReader(file);
                    BufferedReader br = new BufferedReader(fr);
                    jsonMsgs = br.readLine();
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }

            }
        }.start();
        return jsonMsgs;
    }


    @GetMapping("/")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public String getMessages() {
        new Thread() {
            public void run() {
                try
                {
                    File file = new File(datapath);
                    FileReader fr = new FileReader(file);
                    BufferedReader br = new BufferedReader(fr);
                    jsonMsgs = br.readLine();
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }.start();
        return jsonMsgs;
    }


    @PutMapping("/")
    @ResponseStatus(HttpStatus.OK)
    public void putMessage(@RequestBody Message request) {
        new Thread() {
            public void run() {
                try
                {
                    File file = new File(datapath);
                    FileReader fr = new FileReader(file);
                    BufferedReader br = new BufferedReader(fr);
                    jsonMsgs = br.readLine();
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }

                Gson gson = new Gson();
                MessagesJson msgs = gson.fromJson(jsonMsgs, MessagesJson.class);
                msgs.names.remove(0);
                msgs.messages.remove(0);
                msgs.names.add(request.name);
                msgs.messages.add(request.message);
                jsonMsgs = gson.toJson(msgs);

                try (FileWriter writer = new FileWriter(datapath, false))
                {
                    writer.write(jsonMsgs);
                    writer.flush();
                }
                catch(IOException ex){
                    System.out.println(ex.getMessage());
                }
            }
        }.start();

    }
}